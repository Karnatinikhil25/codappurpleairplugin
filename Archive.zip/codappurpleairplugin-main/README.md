# codappurpleairplugin

Link to codap [source repo](https://github.com/concord-consortium/codap/wiki/CODAP-Data-Interactive-Plugin-API), [examples](https://github.com/concord-consortium/codap-data-interactives) and [tutorial](https://docs.google.com/document/d/1n1ebVKGliXfnTgRns4gtPw2bP6J41XMht2bNMMcAw9o/edit#).
Main branch is automatically deployed [here](https://vverma9.github.io/codappurpleairplugin/) using the github pages, therefore please create a PR instead of directly committing your code in main. 
[Here](https://codap.concord.org/releases/latest/static/dg/en/cert/index.html?di=https://vverma9.github.io/codappurpleairplugin/) is the app plugged into the codap tool.

[Here](https://github.com/vverma9/codappurpleairplugin/issues) is a list of all the features that you can work on
To run the tool on your local, simply open the `index.html` file in your browser.
